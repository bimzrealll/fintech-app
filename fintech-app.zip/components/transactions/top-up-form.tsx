"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, CheckCircle, CreditCard } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface TopUpFormProps {
  onSuccess: () => void
}

export function TopUpForm({ onSuccess }: TopUpFormProps) {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [formData, setFormData] = useState({
    amount: "",
    method: "card",
  })
  const { toast } = useToast()

  const quickAmounts = [50, 100, 250, 500]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      setSuccess(true)
      toast({
        title: "Top Up Successful",
        description: `$${formData.amount} added to your account`,
      })

      setTimeout(() => {
        onSuccess()
        setSuccess(false)
      }, 2000)
    } catch (error) {
      toast({
        title: "Top Up Failed",
        description: "Please try again later",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="text-center py-8">
        <CheckCircle size={64} className="mx-auto text-accent mb-4" />
        <h3 className="text-lg font-semibold mb-2">Top Up Successful!</h3>
        <p className="text-muted-foreground">Funds have been added to your account</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="method">Payment Method</Label>
        <Select value={formData.method} onValueChange={(value) => setFormData({ ...formData, method: value })}>
          <SelectTrigger className="glass bg-input/50">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="card">Credit/Debit Card</SelectItem>
            <SelectItem value="bank">Bank Transfer</SelectItem>
            <SelectItem value="paypal">PayPal</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Quick Amounts</Label>
        <div className="grid grid-cols-4 gap-2">
          {quickAmounts.map((amount) => (
            <Button
              key={amount}
              type="button"
              variant="outline"
              size="sm"
              className="glass bg-transparent"
              onClick={() => setFormData({ ...formData, amount: amount.toString() })}
            >
              ${amount}
            </Button>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="amount">Custom Amount</Label>
        <Input
          id="amount"
          type="number"
          placeholder="0.00"
          value={formData.amount}
          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
          required
          min="0.01"
          step="0.01"
          className="glass bg-input/50"
        />
      </div>

      <div className="glass p-4 rounded-lg flex items-center space-x-3">
        <CreditCard size={20} className="text-muted-foreground" />
        <div>
          <p className="text-sm font-medium">•••• •••• •••• 4242</p>
          <p className="text-xs text-muted-foreground">Expires 12/25</p>
        </div>
      </div>

      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          `Add $${formData.amount || "0.00"}`
        )}
      </Button>
    </form>
  )
}
