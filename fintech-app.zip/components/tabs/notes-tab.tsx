"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Plus,
  Search,
  FileText,
  Receipt,
  Camera,
  Paperclip,
  Edit,
  Trash2,
  Calendar,
  Tag,
  ImageIcon,
} from "lucide-react"

interface Note {
  id: number
  title: string
  content: string
  category: string
  tags: string[]
  date: string
  type: "note" | "receipt"
  attachments?: string[]
  amount?: number
  merchant?: string
}

export function NotesTab() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filterCategory, setFilterCategory] = useState("all")
  const [filterType, setFilterType] = useState("all")
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [editingNote, setEditingNote] = useState<Note | null>(null)
  const [newNote, setNewNote] = useState({
    title: "",
    content: "",
    category: "general",
    tags: "",
    type: "note" as "note" | "receipt",
    amount: "",
    merchant: "",
  })

  const [notes, setNotes] = useState<Note[]>([
    {
      id: 1,
      title: "Coffee Shop Receipt",
      content: "Morning coffee and pastry. Great service as always.",
      category: "food",
      tags: ["coffee", "breakfast"],
      date: "2024-01-20",
      type: "receipt",
      attachments: ["/coffee-shop-receipt.png"],
      amount: 4.5,
      merchant: "Starbucks",
    },
    {
      id: 2,
      title: "Investment Research Notes",
      content: "Researched tech stocks for Q1 portfolio rebalancing. Focus on AI and cloud computing sectors.",
      category: "investment",
      tags: ["stocks", "research", "tech"],
      date: "2024-01-19",
      type: "note",
    },
    {
      id: 3,
      title: "Grocery Receipt - Weekly Shopping",
      content: "Weekly grocery shopping. Bought organic vegetables and household items.",
      category: "shopping",
      tags: ["groceries", "weekly"],
      date: "2024-01-18",
      type: "receipt",
      attachments: ["/placeholder-hoxio.png"],
      amount: 127.45,
      merchant: "Whole Foods",
    },
    {
      id: 4,
      title: "Tax Preparation Checklist",
      content: "Documents needed: W2, 1099s, mortgage interest, charitable donations, medical expenses.",
      category: "tax",
      tags: ["taxes", "documents", "checklist"],
      date: "2024-01-15",
      type: "note",
    },
    {
      id: 5,
      title: "Restaurant Receipt - Business Dinner",
      content: "Client dinner at Italian restaurant. Discussed Q1 project timeline and deliverables.",
      category: "business",
      tags: ["business", "client", "dinner"],
      date: "2024-01-12",
      type: "receipt",
      attachments: ["/restaurant-receipt.png"],
      amount: 89.75,
      merchant: "Luigi's Italian",
    },
  ])

  const categories = [
    { value: "all", label: "All Categories" },
    { value: "general", label: "General" },
    { value: "food", label: "Food & Dining" },
    { value: "shopping", label: "Shopping" },
    { value: "business", label: "Business" },
    { value: "investment", label: "Investment" },
    { value: "tax", label: "Tax" },
    { value: "travel", label: "Travel" },
  ]

  const filteredNotes = notes.filter((note) => {
    const matchesSearch =
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesCategory = filterCategory === "all" || note.category === filterCategory
    const matchesType = filterType === "all" || note.type === filterType

    return matchesSearch && matchesCategory && matchesType
  })

  const handleCreateNote = () => {
    if (!newNote.title.trim()) return

    const note: Note = {
      id: Date.now(),
      title: newNote.title,
      content: newNote.content,
      category: newNote.category,
      tags: newNote.tags
        .split(",")
        .map((tag) => tag.trim())
        .filter(Boolean),
      date: new Date().toISOString().split("T")[0],
      type: newNote.type,
      ...(newNote.type === "receipt" && {
        amount: Number.parseFloat(newNote.amount) || 0,
        merchant: newNote.merchant,
      }),
    }

    setNotes([note, ...notes])
    setNewNote({
      title: "",
      content: "",
      category: "general",
      tags: "",
      type: "note",
      amount: "",
      merchant: "",
    })
    setIsCreateModalOpen(false)
  }

  const handleDeleteNote = (id: number) => {
    setNotes(notes.filter((note) => note.id !== id))
  }

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      general: "bg-muted text-muted-foreground",
      food: "bg-orange-500/20 text-orange-600",
      shopping: "bg-blue-500/20 text-blue-600",
      business: "bg-purple-500/20 text-purple-600",
      investment: "bg-green-500/20 text-green-600",
      tax: "bg-red-500/20 text-red-600",
      travel: "bg-cyan-500/20 text-cyan-600",
    }
    return colors[category] || colors.general
  }

  return (
    <div className="p-4 pt-12 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Notes & Receipts</h1>
          <p className="text-muted-foreground">Organize your financial documents and notes</p>
        </div>
        <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus size={16} className="mr-2" />
              Add Note
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-strong border-0 shadow-2xl max-w-md">
            <DialogHeader>
              <DialogTitle>Create New {newNote.type === "note" ? "Note" : "Receipt"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex gap-2">
                <Button
                  variant={newNote.type === "note" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setNewNote({ ...newNote, type: "note" })}
                  className="flex-1"
                >
                  <FileText size={16} className="mr-2" />
                  Note
                </Button>
                <Button
                  variant={newNote.type === "receipt" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setNewNote({ ...newNote, type: "receipt" })}
                  className="flex-1"
                >
                  <Receipt size={16} className="mr-2" />
                  Receipt
                </Button>
              </div>

              <Input
                placeholder="Title"
                value={newNote.title}
                onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
                className="glass bg-input/50"
              />

              <Textarea
                placeholder="Content"
                value={newNote.content}
                onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                className="glass bg-input/50"
                rows={4}
              />

              <Select value={newNote.category} onValueChange={(value) => setNewNote({ ...newNote, category: value })}>
                <SelectTrigger className="glass bg-input/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.slice(1).map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Input
                placeholder="Tags (comma separated)"
                value={newNote.tags}
                onChange={(e) => setNewNote({ ...newNote, tags: e.target.value })}
                className="glass bg-input/50"
              />

              {newNote.type === "receipt" && (
                <>
                  <Input
                    placeholder="Merchant"
                    value={newNote.merchant}
                    onChange={(e) => setNewNote({ ...newNote, merchant: e.target.value })}
                    className="glass bg-input/50"
                  />
                  <Input
                    placeholder="Amount"
                    type="number"
                    step="0.01"
                    value={newNote.amount}
                    onChange={(e) => setNewNote({ ...newNote, amount: e.target.value })}
                    className="glass bg-input/50"
                  />
                </>
              )}

              <div className="flex gap-2">
                <Button variant="outline" className="flex-1 glass bg-transparent">
                  <Camera size={16} className="mr-2" />
                  Camera
                </Button>
                <Button variant="outline" className="flex-1 glass bg-transparent">
                  <Paperclip size={16} className="mr-2" />
                  Attach
                </Button>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setIsCreateModalOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleCreateNote} className="flex-1">
                  Create {newNote.type === "note" ? "Note" : "Receipt"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="glass">
          <CardContent className="p-4 text-center">
            <FileText size={24} className="mx-auto mb-2 text-primary" />
            <p className="text-sm text-muted-foreground">Total Notes</p>
            <p className="text-xl font-bold">{notes.filter((n) => n.type === "note").length}</p>
          </CardContent>
        </Card>
        <Card className="glass">
          <CardContent className="p-4 text-center">
            <Receipt size={24} className="mx-auto mb-2 text-accent" />
            <p className="text-sm text-muted-foreground">Receipts</p>
            <p className="text-xl font-bold">{notes.filter((n) => n.type === "receipt").length}</p>
          </CardContent>
        </Card>
        <Card className="glass">
          <CardContent className="p-4 text-center">
            <ImageIcon size={24} className="mx-auto mb-2 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">Attachments</p>
            <p className="text-xl font-bold">{notes.filter((n) => n.attachments?.length).length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card className="glass">
        <CardContent className="p-4 space-y-4">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search notes and receipts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 glass bg-input/50"
            />
          </div>
          <div className="flex gap-3">
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="glass bg-input/50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    {category.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="glass bg-input/50">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="note">Notes</SelectItem>
                <SelectItem value="receipt">Receipts</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Notes List */}
      <div className="space-y-4">
        {filteredNotes.map((note) => (
          <Card key={note.id} className="glass">
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      note.type === "note" ? "bg-primary/20" : "bg-accent/20"
                    }`}
                  >
                    {note.type === "note" ? (
                      <FileText size={18} className="text-primary" />
                    ) : (
                      <Receipt size={18} className="text-accent" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold">{note.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge className={`text-xs ${getCategoryColor(note.category)}`}>
                        {categories.find((c) => c.value === note.category)?.label}
                      </Badge>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Calendar size={12} />
                        {note.date}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <Edit size={14} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 text-destructive"
                    onClick={() => handleDeleteNote(note.id)}
                  >
                    <Trash2 size={14} />
                  </Button>
                </div>
              </div>

              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{note.content}</p>

              {note.type === "receipt" && (note.amount || note.merchant) && (
                <div className="flex items-center justify-between mb-3 p-3 rounded-lg glass-strong">
                  <span className="text-sm text-muted-foreground">
                    {note.merchant && `${note.merchant} • `}
                    {note.amount && `$${note.amount}`}
                  </span>
                </div>
              )}

              {note.attachments && note.attachments.length > 0 && (
                <div className="mb-3">
                  <div className="flex gap-2 overflow-x-auto">
                    {note.attachments.map((attachment, index) => (
                      <div key={index} className="flex-shrink-0">
                        <img
                          src={attachment || "/placeholder.svg"}
                          alt={`Attachment ${index + 1}`}
                          className="w-20 h-20 object-cover rounded-lg glass"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {note.tags.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {note.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      <Tag size={10} className="mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredNotes.length === 0 && (
        <Card className="glass">
          <CardContent className="p-8 text-center">
            <FileText size={48} className="mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No notes found</h3>
            <p className="text-muted-foreground mb-4">Create your first note or receipt to get started</p>
            <Button onClick={() => setIsCreateModalOpen(true)}>
              <Plus size={16} className="mr-2" />
              Create Note
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
