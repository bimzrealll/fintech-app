"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, CheckCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface TransferFormProps {
  onSuccess: () => void
}

export function TransferForm({ onSuccess }: TransferFormProps) {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [formData, setFormData] = useState({
    recipient: "",
    amount: "",
    description: "",
    transferType: "internal",
  })
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      setSuccess(true)
      toast({
        title: "Transfer Successful",
        description: `$${formData.amount} transferred successfully`,
      })

      setTimeout(() => {
        onSuccess()
        setSuccess(false)
      }, 2000)
    } catch (error) {
      toast({
        title: "Transfer Failed",
        description: "Please try again later",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="text-center py-8">
        <CheckCircle size={64} className="mx-auto text-accent mb-4" />
        <h3 className="text-lg font-semibold mb-2">Transfer Successful!</h3>
        <p className="text-muted-foreground">Your transfer has been processed</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="transferType">Transfer Type</Label>
        <Select
          value={formData.transferType}
          onValueChange={(value) => setFormData({ ...formData, transferType: value })}
        >
          <SelectTrigger className="glass bg-input/50">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="internal">Internal Transfer</SelectItem>
            <SelectItem value="external">External Bank</SelectItem>
            <SelectItem value="international">International</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="recipient">Recipient</Label>
        <Input
          id="recipient"
          placeholder="Enter recipient details"
          value={formData.recipient}
          onChange={(e) => setFormData({ ...formData, recipient: e.target.value })}
          required
          className="glass bg-input/50"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="amount">Amount</Label>
        <Input
          id="amount"
          type="number"
          placeholder="0.00"
          value={formData.amount}
          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
          required
          min="0.01"
          step="0.01"
          className="glass bg-input/50"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description (Optional)</Label>
        <Textarea
          id="description"
          placeholder="Add a note..."
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="glass bg-input/50"
          rows={3}
        />
      </div>

      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          `Transfer $${formData.amount || "0.00"}`
        )}
      </Button>
    </form>
  )
}
