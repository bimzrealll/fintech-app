"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Camera, Upload, QrCode, Receipt, CheckCircle, X, Scan } from "lucide-react"

export function ScanTab() {
  const [scanMode, setScanMode] = useState<"qr" | "receipt" | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const [scanResult, setScanResult] = useState<any>(null)

  const recentScans = [
    {
      id: 1,
      type: "qr",
      title: "Coffee Shop Payment",
      amount: 4.5,
      date: "Today, 9:30 AM",
      status: "completed",
    },
    {
      id: 2,
      type: "receipt",
      title: "Grocery Receipt",
      amount: 127.45,
      date: "Yesterday, 6:15 PM",
      status: "processed",
    },
    {
      id: 3,
      type: "qr",
      title: "Restaurant Bill",
      amount: 89.75,
      date: "Jan 8, 7:45 PM",
      status: "completed",
    },
  ]

  const handleQRScan = () => {
    setScanMode("qr")
    setIsScanning(true)

    // Simulate QR scan
    setTimeout(() => {
      setIsScanning(false)
      setScanResult({
        type: "qr",
        merchant: "Coffee Shop",
        amount: 4.5,
        description: "Latte + Croissant",
      })
    }, 3000)
  }

  const handleReceiptScan = () => {
    setScanMode("receipt")
    setIsScanning(true)

    // Simulate receipt scan
    setTimeout(() => {
      setIsScanning(false)
      setScanResult({
        type: "receipt",
        merchant: "Grocery Store",
        amount: 67.89,
        items: [
          { name: "Milk", price: 3.99 },
          { name: "Bread", price: 2.5 },
          { name: "Eggs", price: 4.99 },
          { name: "Apples", price: 5.67 },
        ],
        date: "2024-01-20",
        tax: 5.42,
        total: 67.89,
      })
    }, 3000)
  }

  const handleConfirmPayment = () => {
    // Process payment
    setScanResult(null)
    setScanMode(null)
  }

  const handleCancelScan = () => {
    setIsScanning(false)
    setScanResult(null)
    setScanMode(null)
  }

  if (isScanning) {
    return (
      <div className="p-4 pt-12 space-y-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">{scanMode === "qr" ? "Scanning QR Code" : "Scanning Receipt"}</h1>
          <p className="text-muted-foreground">
            {scanMode === "qr" ? "Point your camera at the QR code" : "Capture the entire receipt"}
          </p>
        </div>

        <Card className="glass-strong">
          <CardContent className="p-8">
            <div className="aspect-square max-w-sm mx-auto bg-black/20 rounded-2xl flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-4 border-2 border-accent rounded-xl animate-pulse" />
              <div className="absolute inset-8 border border-accent/50 rounded-lg" />
              {scanMode === "qr" ? (
                <QrCode size={64} className="text-accent animate-pulse" />
              ) : (
                <Receipt size={64} className="text-accent animate-pulse" />
              )}
            </div>
          </CardContent>
        </Card>

        <div className="flex gap-3">
          <Button variant="outline" onClick={handleCancelScan} className="flex-1 glass bg-transparent">
            <X size={16} className="mr-2" />
            Cancel
          </Button>
          <Button className="flex-1">
            <Scan size={16} className="mr-2" />
            Scanning...
          </Button>
        </div>
      </div>
    )
  }

  if (scanResult) {
    return (
      <div className="p-4 pt-12 space-y-6">
        <div className="text-center">
          <CheckCircle size={64} className="mx-auto mb-4 text-accent" />
          <h1 className="text-2xl font-bold mb-2">
            {scanResult.type === "qr" ? "QR Code Scanned" : "Receipt Processed"}
          </h1>
          <p className="text-muted-foreground">Review the details below</p>
        </div>

        <Card className="glass-strong">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {scanResult.type === "qr" ? <QrCode size={20} /> : <Receipt size={20} />}
              {scanResult.merchant}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {scanResult.type === "qr" ? (
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Amount</span>
                  <span className="font-semibold">${scanResult.amount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Description</span>
                  <span>{scanResult.description}</span>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label>Items</Label>
                  {scanResult.items.map((item: any, index: number) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span>{item.name}</span>
                      <span>${item.price}</span>
                    </div>
                  ))}
                </div>
                <div className="border-t pt-3 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Subtotal</span>
                    <span>${(scanResult.total - scanResult.tax).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Tax</span>
                    <span>${scanResult.tax}</span>
                  </div>
                  <div className="flex justify-between font-semibold">
                    <span>Total</span>
                    <span>${scanResult.total}</span>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex gap-3">
          <Button variant="outline" onClick={handleCancelScan} className="flex-1 glass bg-transparent">
            Cancel
          </Button>
          {scanResult.type === "qr" && (
            <Button onClick={handleConfirmPayment} className="flex-1">
              Pay ${scanResult.amount}
            </Button>
          )}
          {scanResult.type === "receipt" && (
            <Button onClick={handleConfirmPayment} className="flex-1">
              Save Receipt
            </Button>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="p-4 pt-12 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Scanner</h1>
        <p className="text-muted-foreground">Scan QR codes for payments or receipts for tracking</p>
      </div>

      {/* Scan Options */}
      <div className="grid grid-cols-1 gap-4">
        <Card className="glass cursor-pointer hover:bg-accent/5 transition-colors" onClick={handleQRScan}>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center">
                <QrCode size={28} className="text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-lg">QR Code Payment</h3>
                <p className="text-muted-foreground">Scan QR codes to make instant payments</p>
              </div>
              <Camera size={20} className="text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass cursor-pointer hover:bg-accent/5 transition-colors" onClick={handleReceiptScan}>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center">
                <Receipt size={28} className="text-accent" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-lg">Receipt Scanner</h3>
                <p className="text-muted-foreground">Digitize receipts for expense tracking</p>
              </div>
              <Camera size={20} className="text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upload Option */}
      <Card className="glass">
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <Upload size={48} className="mx-auto text-muted-foreground" />
            <div>
              <h3 className="font-semibold">Upload from Gallery</h3>
              <p className="text-sm text-muted-foreground">Select QR codes or receipts from your photos</p>
            </div>
            <Button variant="outline" className="glass bg-transparent">
              <Upload size={16} className="mr-2" />
              Choose File
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Scans */}
      <Card className="glass">
        <CardHeader>
          <CardTitle className="text-lg">Recent Scans</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {recentScans.map((scan) => (
            <div key={scan.id} className="flex items-center justify-between p-3 rounded-lg glass-strong">
              <div className="flex items-center space-x-3">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    scan.type === "qr" ? "bg-primary/20" : "bg-accent/20"
                  }`}
                >
                  {scan.type === "qr" ? (
                    <QrCode size={16} className="text-primary" />
                  ) : (
                    <Receipt size={16} className="text-accent" />
                  )}
                </div>
                <div>
                  <p className="font-medium">{scan.title}</p>
                  <p className="text-sm text-muted-foreground">{scan.date}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold">${scan.amount}</p>
                <Badge
                  className={`text-xs ${
                    scan.status === "completed" ? "bg-accent/20 text-accent" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {scan.status}
                </Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
