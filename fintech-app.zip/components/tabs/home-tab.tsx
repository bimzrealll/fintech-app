"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  ArrowUpRight,
  ArrowDownLeft,
  QrCode,
  Plus,
  TrendingUp,
  TrendingDown,
  Eye,
  EyeOff,
  CreditCard,
  PiggyBank,
  Target,
} from "lucide-react"
import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { TransactionModal } from "@/components/transactions/transaction-modal"

export function HomeTab() {
  const [showBalance, setShowBalance] = useState(true)
  const [transactionModal, setTransactionModal] = useState<{
    isOpen: boolean
    type: "transfer" | "withdraw" | "qr-pay" | "top-up" | null
  }>({
    isOpen: false,
    type: null,
  })
  const { user } = useAuth()

  // Mock data - in real app this would come from Firebase
  const balance = 12450.0
  const monthlyChange = 2.5
  const savingsGoal = 15000
  const currentSavings = 8750

  const recentTransactions = [
    {
      id: 1,
      title: "Coffee Shop",
      category: "Food & Dining",
      amount: -4.5,
      date: "Today, 9:30 AM",
      type: "expense",
    },
    {
      id: 2,
      title: "Salary Deposit",
      category: "Income",
      amount: 3200.0,
      date: "Yesterday, 2:00 PM",
      type: "income",
    },
    {
      id: 3,
      title: "Netflix Subscription",
      category: "Entertainment",
      amount: -15.99,
      date: "Dec 15, 11:45 PM",
      type: "expense",
    },
    {
      id: 4,
      title: "Freelance Payment",
      category: "Income",
      amount: 850.0,
      date: "Dec 14, 3:20 PM",
      type: "income",
    },
  ]

  const quickStats = [
    {
      title: "This Month",
      amount: 2840.5,
      change: 12.5,
      icon: TrendingUp,
      positive: true,
    },
    {
      title: "Last Month",
      amount: 3120.75,
      change: -8.2,
      icon: TrendingDown,
      positive: false,
    },
  ]

  const openTransactionModal = (type: "transfer" | "withdraw" | "qr-pay" | "top-up") => {
    setTransactionModal({ isOpen: true, type })
  }

  const closeTransactionModal = () => {
    setTransactionModal({ isOpen: false, type: null })
  }

  return (
    <div className="p-4 space-y-6">
      <div className="pt-8">
        <h1 className="text-2xl font-bold text-foreground">Good morning, {user?.email?.split("@")[0] || "User"}</h1>
        <p className="text-muted-foreground">Here's your financial overview</p>
      </div>

      <Card className="glass-strong border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-muted-foreground">Total Balance</p>
            <Button variant="ghost" size="sm" onClick={() => setShowBalance(!showBalance)} className="h-8 w-8 p-0">
              {showBalance ? <Eye size={16} /> : <EyeOff size={16} />}
            </Button>
          </div>
          <div className="text-center space-y-2">
            <p className="text-3xl font-bold">{showBalance ? `$${balance.toLocaleString()}` : "••••••"}</p>
            <div className="flex items-center justify-center gap-2">
              <TrendingUp size={16} className="text-accent" />
              <p className="text-sm text-accent">+{monthlyChange}% from last month</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-4">
        {quickStats.map((stat, index) => (
          <Card key={index} className="glass">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <stat.icon size={16} className={stat.positive ? "text-accent" : "text-destructive"} />
                <span className={`text-xs ${stat.positive ? "text-accent" : "text-destructive"}`}>
                  {stat.positive ? "+" : ""}
                  {stat.change}%
                </span>
              </div>
              <p className="text-xs text-muted-foreground">{stat.title}</p>
              <p className="font-semibold">${stat.amount.toLocaleString()}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Button
          className="h-20 flex-col gap-2 bg-primary hover:bg-primary/90 shadow-lg"
          onClick={() => openTransactionModal("transfer")}
        >
          <ArrowUpRight size={24} />
          <span className="text-sm font-medium">Transfer</span>
        </Button>
        <Button
          variant="outline"
          className="h-20 flex-col gap-2 glass bg-transparent border-border/20 hover:bg-accent/10"
          onClick={() => openTransactionModal("withdraw")}
        >
          <ArrowDownLeft size={24} />
          <span className="text-sm font-medium">Withdraw</span>
        </Button>
        <Button
          variant="outline"
          className="h-20 flex-col gap-2 glass bg-transparent border-border/20 hover:bg-accent/10"
          onClick={() => openTransactionModal("qr-pay")}
        >
          <QrCode size={24} />
          <span className="text-sm font-medium">QR Pay</span>
        </Button>
        <Button
          variant="outline"
          className="h-20 flex-col gap-2 glass bg-transparent border-border/20 hover:bg-accent/10"
          onClick={() => openTransactionModal("top-up")}
        >
          <Plus size={24} />
          <span className="text-sm font-medium">Top Up</span>
        </Button>
      </div>

      <Card className="glass">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <Target size={20} className="text-accent" />
              Savings Goal
            </CardTitle>
            <span className="text-sm text-muted-foreground">
              ${currentSavings.toLocaleString()} / ${savingsGoal.toLocaleString()}
            </span>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <Progress value={(currentSavings / savingsGoal) * 100} className="h-2" />
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">{Math.round((currentSavings / savingsGoal) * 100)}% complete</span>
            <span className="text-accent font-medium">${(savingsGoal - currentSavings).toLocaleString()} to go</span>
          </div>
        </CardContent>
      </Card>

      <Card className="glass">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Recent Transactions</CardTitle>
            <Button variant="ghost" size="sm" className="text-accent">
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {recentTransactions.map((transaction) => (
            <div key={transaction.id} className="flex items-center justify-between p-3 rounded-lg glass-strong">
              <div className="flex items-center space-x-3">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    transaction.type === "income" ? "bg-accent/20" : "bg-destructive/20"
                  }`}
                >
                  {transaction.type === "income" ? (
                    <TrendingUp size={16} className="text-accent" />
                  ) : (
                    <CreditCard size={16} className="text-destructive" />
                  )}
                </div>
                <div>
                  <p className="font-medium">{transaction.title}</p>
                  <p className="text-sm text-muted-foreground">{transaction.category}</p>
                  <p className="text-xs text-muted-foreground">{transaction.date}</p>
                </div>
              </div>
              <p className={`font-semibold ${transaction.type === "income" ? "text-accent" : "text-destructive"}`}>
                {transaction.type === "income" ? "+" : ""}${Math.abs(transaction.amount).toLocaleString()}
              </p>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-4">
        <Card className="glass">
          <CardContent className="p-4 text-center">
            <CreditCard size={24} className="mx-auto mb-2 text-primary" />
            <p className="text-sm text-muted-foreground">Active Cards</p>
            <p className="text-xl font-bold">3</p>
          </CardContent>
        </Card>
        <Card className="glass">
          <CardContent className="p-4 text-center">
            <PiggyBank size={24} className="mx-auto mb-2 text-accent" />
            <p className="text-sm text-muted-foreground">Savings Rate</p>
            <p className="text-xl font-bold">23%</p>
          </CardContent>
        </Card>
      </div>

      <TransactionModal isOpen={transactionModal.isOpen} onClose={closeTransactionModal} type={transactionModal.type} />
    </div>
  )
}
