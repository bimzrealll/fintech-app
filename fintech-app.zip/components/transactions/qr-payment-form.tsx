"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, CheckCircle, Camera, Upload } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface QrPaymentFormProps {
  onSuccess: () => void
}

export function QrPaymentForm({ onSuccess }: QrPaymentFormProps) {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [scanMode, setScanMode] = useState(false)
  const [formData, setFormData] = useState({
    amount: "",
    description: "",
  })
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      setSuccess(true)
      toast({
        title: "Payment Successful",
        description: `$${formData.amount} paid via QR`,
      })

      setTimeout(() => {
        onSuccess()
        setSuccess(false)
      }, 2000)
    } catch (error) {
      toast({
        title: "Payment Failed",
        description: "Please try again later",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleScan = () => {
    setScanMode(true)
    // Simulate QR scan
    setTimeout(() => {
      setScanMode(false)
      setFormData({ ...formData, amount: "25.50" })
      toast({
        title: "QR Code Scanned",
        description: "Payment details loaded",
      })
    }, 2000)
  }

  if (success) {
    return (
      <div className="text-center py-8">
        <CheckCircle size={64} className="mx-auto text-accent mb-4" />
        <h3 className="text-lg font-semibold mb-2">Payment Successful!</h3>
        <p className="text-muted-foreground">Your QR payment has been processed</p>
      </div>
    )
  }

  if (scanMode) {
    return (
      <div className="text-center py-8">
        <div className="w-48 h-48 mx-auto mb-4 glass rounded-lg flex items-center justify-center">
          <Camera size={48} className="text-muted-foreground animate-pulse" />
        </div>
        <p className="text-muted-foreground">Scanning QR code...</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Button onClick={handleScan} variant="outline" className="glass bg-transparent">
          <Camera className="mr-2 h-4 w-4" />
          Scan QR
        </Button>
        <Button variant="outline" className="glass bg-transparent">
          <Upload className="mr-2 h-4 w-4" />
          Upload
        </Button>
      </div>

      <div className="text-center text-sm text-muted-foreground">or enter details manually</div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="amount">Amount</Label>
          <Input
            id="amount"
            type="number"
            placeholder="0.00"
            value={formData.amount}
            onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
            required
            min="0.01"
            step="0.01"
            className="glass bg-input/50"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description (Optional)</Label>
          <Textarea
            id="description"
            placeholder="Payment for..."
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="glass bg-input/50"
            rows={3}
          />
        </div>

        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            `Pay $${formData.amount || "0.00"}`
          )}
        </Button>
      </form>
    </div>
  )
}
