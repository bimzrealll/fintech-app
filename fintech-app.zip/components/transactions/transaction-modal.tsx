"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { TransferForm } from "./transfer-form"
import { WithdrawForm } from "./withdraw-form"
import { QrPaymentForm } from "./qr-payment-form"
import { TopUpForm } from "./top-up-form"

interface TransactionModalProps {
  isOpen: boolean
  onClose: () => void
  type: "transfer" | "withdraw" | "qr-pay" | "top-up" | null
}

export function TransactionModal({ isOpen, onClose, type }: TransactionModalProps) {
  const getTitle = () => {
    switch (type) {
      case "transfer":
        return "Transfer Money"
      case "withdraw":
        return "Withdraw Funds"
      case "qr-pay":
        return "QR Payment"
      case "top-up":
        return "Top Up Account"
      default:
        return "Transaction"
    }
  }

  const renderForm = () => {
    switch (type) {
      case "transfer":
        return <TransferForm onSuccess={onClose} />
      case "withdraw":
        return <WithdrawForm onSuccess={onClose} />
      case "qr-pay":
        return <QrPaymentForm onSuccess={onClose} />
      case "top-up":
        return <TopUpForm onSuccess={onClose} />
      default:
        return null
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-strong border-0 shadow-2xl max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">{getTitle()}</DialogTitle>
        </DialogHeader>
        {renderForm()}
      </DialogContent>
    </Dialog>
  )
}
