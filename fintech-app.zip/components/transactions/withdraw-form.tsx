"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, CheckCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface WithdrawFormProps {
  onSuccess: () => void
}

export function WithdrawForm({ onSuccess }: WithdrawFormProps) {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [formData, setFormData] = useState({
    amount: "",
    method: "bank",
  })
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      setSuccess(true)
      toast({
        title: "Withdrawal Successful",
        description: `$${formData.amount} withdrawal initiated`,
      })

      setTimeout(() => {
        onSuccess()
        setSuccess(false)
      }, 2000)
    } catch (error) {
      toast({
        title: "Withdrawal Failed",
        description: "Please try again later",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="text-center py-8">
        <CheckCircle size={64} className="mx-auto text-accent mb-4" />
        <h3 className="text-lg font-semibold mb-2">Withdrawal Initiated!</h3>
        <p className="text-muted-foreground">Funds will be available in 1-2 business days</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="method">Withdrawal Method</Label>
        <Select value={formData.method} onValueChange={(value) => setFormData({ ...formData, method: value })}>
          <SelectTrigger className="glass bg-input/50">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="bank">Bank Transfer</SelectItem>
            <SelectItem value="atm">ATM Withdrawal</SelectItem>
            <SelectItem value="check">Check</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="amount">Amount</Label>
        <Input
          id="amount"
          type="number"
          placeholder="0.00"
          value={formData.amount}
          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
          required
          min="0.01"
          step="0.01"
          className="glass bg-input/50"
        />
      </div>

      <div className="glass p-4 rounded-lg">
        <p className="text-sm text-muted-foreground">
          <strong>Available Balance:</strong> $12,450.00
        </p>
        <p className="text-xs text-muted-foreground mt-1">Daily withdrawal limit: $5,000.00</p>
      </div>

      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          `Withdraw $${formData.amount || "0.00"}`
        )}
      </Button>
    </form>
  )
}
