"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Download,
  TrendingUp,
  TrendingDown,
  CreditCard,
  ArrowUpRight,
  ArrowDownLeft,
  QrCode,
  MoreVertical,
} from "lucide-react"

export function HistoryTab() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [filterPeriod, setFilterPeriod] = useState("all")

  // Mock transaction data
  const transactions = [
    {
      id: 1,
      title: "Coffee Shop",
      category: "Food & Dining",
      amount: -4.5,
      date: "2024-01-20",
      time: "9:30 AM",
      type: "expense",
      status: "completed",
      method: "card",
      description: "Morning coffee at Starbucks",
    },
    {
      id: 2,
      title: "Salary Deposit",
      category: "Income",
      amount: 3200.0,
      date: "2024-01-19",
      time: "2:00 PM",
      type: "income",
      status: "completed",
      method: "transfer",
      description: "Monthly salary payment",
    },
    {
      id: 3,
      title: "Netflix Subscription",
      category: "Entertainment",
      amount: -15.99,
      date: "2024-01-15",
      time: "11:45 PM",
      type: "expense",
      status: "completed",
      method: "card",
      description: "Monthly subscription fee",
    },
    {
      id: 4,
      title: "Freelance Payment",
      category: "Income",
      amount: 850.0,
      date: "2024-01-14",
      time: "3:20 PM",
      type: "income",
      status: "completed",
      method: "transfer",
      description: "Web development project",
    },
    {
      id: 5,
      title: "Grocery Store",
      category: "Shopping",
      amount: -127.45,
      date: "2024-01-13",
      time: "6:15 PM",
      type: "expense",
      status: "completed",
      method: "card",
      description: "Weekly grocery shopping",
    },
    {
      id: 6,
      title: "Gas Station",
      category: "Transportation",
      amount: -45.2,
      date: "2024-01-12",
      time: "8:00 AM",
      type: "expense",
      status: "completed",
      method: "card",
      description: "Fuel for car",
    },
    {
      id: 7,
      title: "Investment Return",
      category: "Investment",
      amount: 234.5,
      date: "2024-01-10",
      time: "10:30 AM",
      type: "income",
      status: "completed",
      method: "transfer",
      description: "Quarterly dividend payment",
    },
    {
      id: 8,
      title: "Restaurant",
      category: "Food & Dining",
      amount: -89.75,
      date: "2024-01-08",
      time: "7:45 PM",
      type: "expense",
      status: "completed",
      method: "card",
      description: "Dinner with friends",
    },
  ]

  const filteredTransactions = transactions.filter((transaction) => {
    const matchesSearch =
      transaction.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.description.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesType = filterType === "all" || transaction.type === filterType

    return matchesSearch && matchesType
  })

  const getTransactionIcon = (transaction: any) => {
    switch (transaction.method) {
      case "transfer":
        return transaction.type === "income" ? ArrowDownLeft : ArrowUpRight
      case "card":
        return CreditCard
      case "qr":
        return QrCode
      default:
        return CreditCard
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-accent/20 text-accent"
      case "pending":
        return "bg-yellow-500/20 text-yellow-600"
      case "failed":
        return "bg-destructive/20 text-destructive"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const totalIncome = filteredTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)

  const totalExpenses = filteredTransactions
    .filter((t) => t.type === "expense")
    .reduce((sum, t) => sum + Math.abs(t.amount), 0)

  return (
    <div className="p-4 pt-12 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Transaction History</h1>
          <p className="text-muted-foreground">Track all your financial activities</p>
        </div>
        <Button variant="outline" size="sm" className="glass bg-transparent">
          <Download size={16} className="mr-2" />
          Export
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="glass">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Income</p>
                <p className="text-xl font-bold text-accent">+${totalIncome.toLocaleString()}</p>
              </div>
              <TrendingUp size={24} className="text-accent" />
            </div>
          </CardContent>
        </Card>
        <Card className="glass">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Expenses</p>
                <p className="text-xl font-bold text-destructive">-${totalExpenses.toLocaleString()}</p>
              </div>
              <TrendingDown size={24} className="text-destructive" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card className="glass">
        <CardContent className="p-4 space-y-4">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search transactions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 glass bg-input/50"
            />
          </div>
          <div className="flex gap-3">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="glass bg-input/50">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="income">Income</SelectItem>
                <SelectItem value="expense">Expenses</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterPeriod} onValueChange={setFilterPeriod}>
              <SelectTrigger className="glass bg-input/50">
                <SelectValue placeholder="Period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="year">This Year</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Transaction List */}
      <div className="space-y-3">
        {filteredTransactions.map((transaction) => {
          const Icon = getTransactionIcon(transaction)
          return (
            <Card key={transaction.id} className="glass">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center ${
                        transaction.type === "income" ? "bg-accent/20" : "bg-destructive/20"
                      }`}
                    >
                      <Icon size={18} className={transaction.type === "income" ? "text-accent" : "text-destructive"} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium">{transaction.title}</p>
                        <Badge className={`text-xs ${getStatusColor(transaction.status)}`}>{transaction.status}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{transaction.category}</p>
                      <p className="text-xs text-muted-foreground">
                        {transaction.date} • {transaction.time}
                      </p>
                      {transaction.description && (
                        <p className="text-xs text-muted-foreground mt-1">{transaction.description}</p>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p
                      className={`font-bold text-lg ${transaction.type === "income" ? "text-accent" : "text-destructive"}`}
                    >
                      {transaction.type === "income" ? "+" : ""}${Math.abs(transaction.amount).toLocaleString()}
                    </p>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <MoreVertical size={16} />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {filteredTransactions.length === 0 && (
        <Card className="glass">
          <CardContent className="p-8 text-center">
            <Search size={48} className="mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No transactions found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filters</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
